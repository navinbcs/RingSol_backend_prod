<?php

namespace Mpdf\Tag;

class Section extends BlockTag
{


}
