<?php

namespace Mpdf\Tag;

class Caption extends BlockTag
{


}
